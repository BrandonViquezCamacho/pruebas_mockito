package ucr.ac.cr.creativeSpace.Model;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name= "tb_espaciosCreativos")
public class CreativeSpace {

    @Id
    Integer id;
    String name;
    String location;
    String type;
    Double price;

    public CreativeSpace() {
    }

    public CreativeSpace(Integer id, String name, String location, String type, Double price) {
        this.id = id;
        this.name = name;
        this.location = location;
        this.type = type;
        this.price = price;
    }


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "CreativeSpace{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", location='" + location + '\'' +
                ", type='" + type + '\'' +
                ", price=" + price +
                '}';
    }
}
