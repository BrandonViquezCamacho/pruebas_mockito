package ucr.ac.cr.creativeSpace.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import ucr.ac.cr.creativeSpace.Model.CreativeSpace;
import ucr.ac.cr.creativeSpace.Model.DTO.CreativeSpaceDTO;
import ucr.ac.cr.creativeSpace.Service.CreativeSpaceService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/spaces")
public class CreativeSpaceController {

    @Autowired
    private CreativeSpaceService services;


    @GetMapping
    public ResponseEntity<?> findAllCreativeSpace() {
        return ResponseEntity.ok(this.services.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> findByIDCreativeSpace(@PathVariable Integer id) {

        CreativeSpaceDTO dto = this.services.findByIDCreativeSpace(id);
        if (dto == null){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No se encontró el espacio creativo");
        }

        return ResponseEntity.ok(dto);
    }

    @PostMapping("/save")
    public ResponseEntity<?> saveCreativeSpace(@Validated @RequestBody CreativeSpace creativeSpace, BindingResult result) {

        if(result.hasErrors()){
            Map<String,String> errors=new HashMap<>();
            for(FieldError error : result.getFieldErrors()){
                errors.put(error.getField(), error.getDefaultMessage());
            }
            return ResponseEntity.badRequest().body(errors);
        }

        CreativeSpaceDTO dto = this.services.findByIDCreativeSpace(creativeSpace.getId());

        if (dto != null){
            return ResponseEntity.status(HttpStatus.CONFLICT).body("El espacio creativo ya se encuentra agregado");
        }

        return ResponseEntity.status(HttpStatus.CREATED).body(this.services.saveCreativeSpace(creativeSpace));
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> editCreativeSpace(@Validated @PathVariable @RequestBody Integer id, CreativeSpace creativeSpace, BindingResult result) {

        if(result.hasErrors()){
            Map<String,String> errors=new HashMap<>();
            for(FieldError error : result.getFieldErrors()){
                errors.put(error.getField(), error.getDefaultMessage());
            }
            return ResponseEntity.badRequest().body(errors);
        }

        CreativeSpaceDTO dto = this.services.findByIDCreativeSpace(id);

        if (dto == null){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("El espacio creativo NO se encuentra agregado");
        }

        return ResponseEntity.status(HttpStatus.CREATED).body(this.services.editCreativeSpace(id, creativeSpace));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteCreativeSpace(@PathVariable Integer id){

        CreativeSpaceDTO dto = this.services.findByIDCreativeSpace(id);

        if( dto == null ){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No se encontró el espacio creativo");
        }
        this.services.deleteCreativeSpace(id);
        return ResponseEntity.noContent().build();
    }


    @GetMapping("/type/{type}")
    public ResponseEntity<?> get_creativeSpace_by_type (@PathVariable String type) {
        List <?> types = this.services.findByType(type);
        if (types.isEmpty()){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No hay espacios creativos con ese tipo");
        }

        return ResponseEntity.ok(types);
    }


    @GetMapping("/location/{location}")
    public ResponseEntity<?> get_creativeSpace_by_location (@PathVariable String location) {
        List <?> locations = this.services.findByLocation(location);
        if (locations.isEmpty()){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No hay espacios creativos con ese tipo");
        }

        return ResponseEntity.ok(locations);
    }

}
