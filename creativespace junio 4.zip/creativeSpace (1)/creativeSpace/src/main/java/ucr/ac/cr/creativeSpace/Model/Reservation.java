package ucr.ac.cr.creativeSpace.Model;

public class Reservation {
}
