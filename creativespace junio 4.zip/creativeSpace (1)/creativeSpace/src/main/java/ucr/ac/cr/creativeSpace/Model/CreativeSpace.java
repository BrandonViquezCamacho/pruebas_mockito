package ucr.ac.cr.creativeSpace.Model;


import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name= "tb_espaciosCreativos")
public class CreativeSpace {

    @Id
    Integer id;
    @NotBlank
    String name;
    @NotBlank
    String location;
    @NotBlank
    String type;
    @NotNull
    Double price;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    public CreativeSpace() {
    }

    public CreativeSpace(Integer id, String name, String location, String type, Double price, User user) {
        this.id = id;
        this.name = name;
        this.location = location;
        this.type = type;
        this.price = price;
        this.user = user;
    }


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    @Override
    public String toString() {
        return "CreativeSpace{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", location='" + location + '\'' +
                ", type='" + type + '\'' +
                ", price=" + price +
                ", user=" + user +
                '}';
    }
}
